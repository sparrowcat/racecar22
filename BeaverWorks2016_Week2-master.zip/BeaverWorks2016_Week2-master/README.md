# BeaverWorks2016

echo.py -redisplays the image from the color camera
moving_blob_test - findes the red color
